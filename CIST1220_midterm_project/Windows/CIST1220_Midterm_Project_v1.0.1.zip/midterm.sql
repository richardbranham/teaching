# This is a comment
select * from my_table;
